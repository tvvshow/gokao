import React, { useState, useEffect } from 'react';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { Dashboard } from './components/Dashboard';
import { AISuggestion } from './components/AISuggestion';
import { UniversitySearch } from './components/UniversitySearch';
import { MockApplication } from './components/MockApplication';
import { SubjectChecker } from './components/SubjectChecker';
import { Community } from './components/Community';
import type { View } from './types';

export type Theme = 'light' | 'dark';

const App: React.FC = () => {
  const [activeView, setActiveView] = useState<View>('dashboard');
  const [user, setUser] = useState({ name: '同学', avatar: 'https://i.pravatar.cc/100' });
  const [theme, setTheme] = useState<Theme>(() => {
    if (typeof window !== 'undefined' && localStorage.theme) {
      return localStorage.theme as Theme;
    }
    if (typeof window !== 'undefined' && window.matchMedia('(prefers-color-scheme: dark)').matches) {
      return 'dark';
    }
    return 'light';
  });

  useEffect(() => {
    const root = window.document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
      root.classList.remove('light');
    } else {
      root.classList.remove('dark');
      root.classList.add('light');
    }
    localStorage.setItem('theme', theme);
  }, [theme]);


  const renderView = () => {
    switch (activeView) {
      case 'dashboard':
        return <Dashboard setActiveView={setActiveView} />;
      case 'ai-suggestion':
        return <AISuggestion />;
      case 'search':
        return <UniversitySearch />;
      case 'mock-application':
        return <MockApplication />;
      case 'subject-checker':
        return <SubjectChecker />;
      case 'community':
        return <Community />;
      default:
        return <Dashboard setActiveView={setActiveView} />;
    }
  };

  return (
    <div className="flex h-screen bg-background text-on-surface-variant dark:bg-dark-background dark:text-dark-on-surface-variant">
      <Sidebar activeView={activeView} setActiveView={setActiveView} />
      <div className="flex flex-1 flex-col overflow-hidden">
        <Header user={user} theme={theme} setTheme={setTheme} />
        <main className="flex-1 overflow-y-auto p-6 lg:p-8">
          {renderView()}
        </main>
      </div>
    </div>
  );
};

export default App;