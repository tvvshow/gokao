export type View = 'dashboard' | 'ai-suggestion' | 'search' | 'mock-application' | 'subject-checker' | 'community';
export type Theme = 'light' | 'dark';

export interface User {
  name: string;
  avatar: string;
}

export interface University {
    name: string;
    province: string;
    city: string;
    type: string; // e.g., '985', '211', '普通'
    tags: string[];
}

export interface Major {
    name: string;
    category: string;
    code: string;
}

export interface AISuggestionTier {
  tier: '冲刺' | '稳妥' | '保底'; // Reach, Target, Safety
  colleges: Array<{
    collegeName: string;
    major: string;
    admissionScore2023: string;
    ranking: string;
    reason: string;
  }>;
}

export interface MockApplicationItem {
    id: number;
    university: string;
    major: string;
    isPinned: boolean;
}