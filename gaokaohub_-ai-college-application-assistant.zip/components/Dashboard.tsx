import React from 'react';
import type { View } from '../types';
import { NAVIGATION_ITEMS } from '../constants';

interface DashboardProps {
  setActiveView: (view: View) => void;
}

const ArrowRightIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3" />
    </svg>
);

const FeatureCard: React.FC<{
  item: { view: View; label: string; icon: React.ComponentType<React.SVGProps<SVGSVGElement>> };
  onClick: (view: View) => void;
}> = ({ item, onClick }) => (
  <div
    className="bg-surface rounded-xl border border-border p-6 group hover:border-primary/50 hover:shadow-soft-lg hover:-translate-y-1 transition-all duration-300 cursor-pointer dark:bg-dark-surface dark:border-dark-border dark:hover:border-dark-primary-DEFAULT/50"
    onClick={() => onClick(item.view)}
  >
    <div className="flex flex-col justify-between h-full">
        <div>
            <div className="w-12 h-12 bg-primary/10 text-primary rounded-lg flex items-center justify-center mb-4 transition-colors duration-300 group-hover:bg-primary/15 dark:bg-dark-primary-DEFAULT/15 dark:text-dark-primary-DEFAULT dark:group-hover:bg-dark-primary-DEFAULT/20">
                <item.icon className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-semibold text-on-surface dark:text-dark-on-surface">{item.label}</h3>
        </div>
        <div className="mt-6">
            <span className="text-primary font-medium text-sm flex items-center dark:text-dark-primary-DEFAULT">
                开始使用 <ArrowRightIcon className="w-4 h-4 ml-1.5 transition-transform duration-300 group-hover:translate-x-1" />
            </span>
        </div>
    </div>
  </div>
);

export const Dashboard: React.FC<DashboardProps> = ({ setActiveView }) => {
  const featureItems = NAVIGATION_ITEMS.filter(item => item.view !== 'dashboard');

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold text-on-surface dark:text-dark-on-surface">欢迎来到 GaokaoHub</h2>
        <p className="text-on-surface-variant dark:text-dark-on-surface-variant mt-2">您的一站式高考志愿填报智能助手。从这里开始您的探索之旅。</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {featureItems.map((item) => (
          <FeatureCard key={item.view} item={item} onClick={setActiveView} />
        ))}
      </div>

      <div className="bg-surface rounded-xl border border-border p-6 dark:bg-dark-surface dark:border-dark-border">
        <h3 className="text-lg font-semibold text-on-surface dark:text-dark-on-surface mb-4">热门资讯</h3>
        <ul className="space-y-3">
          <li className="flex items-center justify-between text-sm py-2 border-b border-border dark:border-dark-border/50">
            <a href="#" className="text-on-surface-variant hover:text-primary dark:text-dark-on-surface-variant dark:hover:text-dark-primary-DEFAULT">2024年高校招生政策全解析</a>
            <span className="text-xs text-on-surface-variant/70 dark:text-dark-on-surface-variant/70">2024-05-20</span>
          </li>
          <li className="flex items-center justify-between text-sm py-2 border-b border-border dark:border-dark-border/50">
            <a href="#" className="text-on-surface-variant hover:text-primary dark:text-dark-on-surface-variant dark:hover:text-dark-primary-DEFAULT">未来十年，哪些专业最有“钱”景？</a>
            <span className="text-xs text-on-surface-variant/70 dark:text-dark-on-surface-variant/70">2024-05-18</span>
          </li>
          <li className="flex items-center justify-between text-sm py-2">
            <a href="#" className="text-on-surface-variant hover:text-primary dark:text-dark-on-surface-variant dark:hover:text-dark-primary-DEFAULT">新高考模式下，如何科学选择选考科目？</a>
            <span className="text-xs text-on-surface-variant/70 dark:text-dark-on-surface-variant/70">2024-05-15</span>
          </li>
        </ul>
      </div>
    </div>
  );
};