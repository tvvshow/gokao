import React from 'react';
import type { User, Theme } from '../types';

interface HeaderProps {
  user: User;
  theme: Theme;
  setTheme: (theme: Theme) => void;
}

const BellIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" d="M14.857 17.082a23.848 23.848 0 005.454-1.31A8.967 8.967 0 0118 9.75v-.7V9A6 6 0 006 9v.75a8.967 8.967 0 01-2.312 6.022c1.733.64 3.56 1.085 5.455 1.31m5.714 0a24.255 24.255 0 01-5.714 0m5.714 0a3 3 0 11-5.714 0" />
    </svg>
);

const SunIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 3v2.25m6.364.386l-1.591 1.591M21 12h-2.25m-.386 6.364l-1.591-1.591M12 18.75V21m-4.95-4.243l-1.59-1.59M3.75 12H6m.386-6.364l1.59 1.59M12 12a4.5 4.5 0 000 9 4.5 4.5 0 000-9z" />
  </svg>
);

const MoonIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M21.752 15.002A9.718 9.718 0 0118 15.75c-5.385 0-9.75-4.365-9.75-9.75 0-1.33.266-2.597.748-3.752A9.753 9.753 0 003 11.25C3 16.635 7.365 21 12.75 21a9.753 9.753 0 009.002-5.998z" />
  </svg>
);


export const Header: React.FC<HeaderProps> = ({ user, theme, setTheme }) => {
  const toggleTheme = () => {
    setTheme(theme === 'light' ? 'dark' : 'light');
  };
  
  return (
    <header className="h-16 flex-shrink-0 bg-surface/80 backdrop-blur-sm border-b border-border flex items-center justify-end px-6 lg:px-8 dark:bg-dark-surface/80 dark:border-dark-border">
      <div className="flex items-center space-x-4">
        <button
          onClick={toggleTheme}
          className="p-2 rounded-full text-on-surface-variant hover:bg-black/5 hover:text-on-surface dark:text-dark-on-surface-variant dark:hover:bg-white/5 dark:hover:text-dark-on-surface"
        >
          {theme === 'light' ? <MoonIcon className="w-6 h-6" /> : <SunIcon className="w-6 h-6" />}
        </button>
        <button className="p-2 rounded-full text-on-surface-variant hover:bg-black/5 hover:text-on-surface dark:text-dark-on-surface-variant dark:hover:bg-white/5 dark:hover:text-dark-on-surface">
            <BellIcon className="w-6 h-6" />
        </button>
        <div className="flex items-center space-x-3">
          <img src={user.avatar} alt="User Avatar" className="w-9 h-9 rounded-full" />
          <div>
            <div className="text-sm font-semibold text-on-surface dark:text-dark-on-surface">{user.name}</div>
            <div className="text-xs text-on-surface-variant dark:text-dark-on-surface-variant">高三学生</div>
          </div>
        </div>
      </div>
    </header>
  );
};