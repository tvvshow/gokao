import React, { useState } from 'react';
import { GAOKAO_SUBJECTS } from '../constants';

const mockEligibility: Record<string, string[]> = {
    "物理,化学,生物": ["理工农医大部分专业", "医学类", "生物科学", "计算机科学"],
    "物理,化学,地理": ["理工类大部分专业", "城市规划", "地理信息系统"],
    "历史,政治,地理": ["文史哲大部分专业", "法学", "社会学", "新闻传播"],
    "物理,生物,地理": ["部分理工科", "地理科学类", "环境科学"],
};

export const SubjectChecker: React.FC = () => {
    const [selectedSubjects, setSelectedSubjects] = useState<string[]>([]);
    const [eligibleMajors, setEligibleMajors] = useState<string[]>([]);

    const handleSubjectToggle = (subject: string) => {
        setSelectedSubjects(prev => {
            if (prev.includes(subject)) {
                return prev.filter(s => s !== subject);
            }
            if (prev.length < 3) {
                return [...prev, subject];
            }
            return prev;
        });
    };

    const handleCheckEligibility = () => {
        if (selectedSubjects.length === 3) {
            const key = selectedSubjects.sort().join(',');
            setEligibleMajors(mockEligibility[key] || ["暂无匹配的专业大类，请尝试其他组合。"]);
        } else {
            setEligibleMajors([]);
        }
    };

    return (
        <div>
            <div className="text-center mb-8">
                <h2 className="text-3xl font-bold text-on-surface dark:text-dark-on-surface">新高考选科校验</h2>
                <p className="text-on-surface-variant mt-2 dark:text-dark-on-surface-variant">选择您的三门选考科目，查看可报考的专业大类。</p>
            </div>

            <div className="max-w-2xl mx-auto bg-surface p-8 rounded-xl border border-border dark:bg-dark-surface dark:border-dark-border">
                <div className="mb-6">
                    <h3 className="font-semibold text-on-surface dark:text-dark-on-surface mb-3">请选择您的3门选考科目</h3>
                    <div className="grid grid-cols-3 gap-4">
                        {GAOKAO_SUBJECTS.map(subject => (
                            <button
                                key={subject}
                                onClick={() => handleSubjectToggle(subject)}
                                className={`p-4 rounded-lg text-center font-semibold border-2 transition-all duration-200 ${
                                    selectedSubjects.includes(subject)
                                        ? 'bg-primary border-primary text-primary-content scale-105 shadow-lg'
                                        : 'bg-transparent border-border hover:border-primary/50 dark:border-dark-border dark:hover:border-dark-primary-DEFAULT/50'
                                } ${
                                    selectedSubjects.length === 3 && !selectedSubjects.includes(subject)
                                        ? 'opacity-50 cursor-not-allowed'
                                        : ''
                                }`}
                                disabled={selectedSubjects.length === 3 && !selectedSubjects.includes(subject)}
                            >
                                {subject}
                            </button>
                        ))}
                    </div>
                </div>

                <button
                    onClick={handleCheckEligibility}
                    disabled={selectedSubjects.length !== 3}
                    className="w-full bg-secondary text-secondary-content font-semibold py-3 rounded-lg hover:bg-secondary-hover transition-colors disabled:bg-slate-300 dark:disabled:bg-slate-600"
                >
                    查询可报专业大类
                </button>
                
                {eligibleMajors.length > 0 && (
                    <div className="mt-8 pt-6 border-t border-border dark:border-dark-border">
                         <h3 className="font-semibold text-on-surface dark:text-dark-on-surface mb-3">您的选科组合可报考以下专业大类：</h3>
                         <div className="flex flex-wrap gap-3">
                            {eligibleMajors.map((major, index) => (
                                <span key={index} className="bg-primary/10 text-primary font-medium px-3 py-1.5 rounded-full text-sm dark:bg-dark-primary-DEFAULT/15 dark:text-dark-primary-DEFAULT">
                                    {major}
                                </span>
                            ))}
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};