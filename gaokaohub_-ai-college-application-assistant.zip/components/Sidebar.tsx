import React from 'react';
import type { View } from '../types';
import { NAVIGATION_ITEMS } from '../constants';

interface SidebarProps {
  activeView: View;
  setActiveView: (view: View) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ activeView, setActiveView }) => {
  return (
    <aside className="w-64 flex-shrink-0 bg-surface border-r border-border flex flex-col dark:bg-dark-surface dark:border-dark-border">
      <div className="h-16 flex items-center justify-center border-b border-border dark:border-dark-border">
        <h1 className="text-xl font-bold text-primary dark:text-dark-primary-DEFAULT">GaokaoHub</h1>
      </div>
      <nav className="flex-1 p-4 space-y-2">
        {NAVIGATION_ITEMS.map((item) => (
          <button
            key={item.view}
            onClick={() => setActiveView(item.view)}
            className={`w-full flex items-center space-x-3 px-4 py-2.5 rounded-lg text-sm font-medium transition-all duration-200 ${
              activeView === item.view
                ? 'bg-primary/10 text-primary dark:bg-dark-primary-DEFAULT/15 dark:text-dark-primary-DEFAULT'
                : 'text-on-surface-variant hover:bg-black/5 dark:text-dark-on-surface-variant dark:hover:bg-white/5'
            }`}
          >
            <item.icon className="w-5 h-5" />
            <span>{item.label}</span>
          </button>
        ))}
      </nav>
       <div className="p-4 border-t border-border dark:border-dark-border">
          <div className="bg-gradient-to-br from-primary/10 to-secondary/10 dark:from-primary/15 dark:to-secondary/15 rounded-lg p-4 text-center">
            <h4 className="font-semibold text-sm text-on-surface dark:text-dark-on-surface">升学规划，快人一步</h4>
            <p className="text-xs text-on-surface-variant dark:text-dark-on-surface-variant mt-1 mb-3">
              立即升级Pro版本，解锁更多强大功能。
            </p>
            <button className="w-full bg-primary text-primary-content text-sm font-semibold py-2 rounded-lg hover:bg-primary-hover transition-colors dark:bg-dark-primary-DEFAULT dark:text-dark-primary-content dark:hover:bg-dark-primary-hover">
              升级到 Pro
            </button>
          </div>
        </div>
    </aside>
  );
};