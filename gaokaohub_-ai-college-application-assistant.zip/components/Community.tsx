import React from 'react';

const mockTopics = [
    { id: 1, author: '迷茫的小鸟', avatar: 'https://i.pravatar.cc/40?u=1', title: '600分在山东能上什么好点的211大学？', replies: 28, time: '2小时前' },
    { id: 2, author: '为梦想奋斗', avatar: 'https://i.pravatar.cc/40?u=2', title: '计算机科学和人工智能专业，未来哪个就业更好？', replies: 45, time: '5小时前' },
    { id: 3, author: '一位焦急的家长', avatar: 'https://i.pravatar.cc/40?u=3', title: '孩子性格内向，适合学师范还是会计？', replies: 15, time: '1天前' },
    { id: 4, author: '学海无涯', avatar: 'https://i.pravatar.cc/40?u=4', title: '双非一本的王牌专业和普通211的普通专业怎么选？', replies: 72, time: '2天前' },
];

export const Community: React.FC = () => {
    return (
        <div>
            <div className="text-center mb-8">
                <h2 className="text-3xl font-bold text-on-surface dark:text-dark-on-surface">社区交流</h2>
                <p className="text-on-surface-variant mt-2 dark:text-dark-on-surface-variant">与万千考生和家长一同交流，解答您的升学疑惑。</p>
            </div>
            
            <div className="max-w-4xl mx-auto">
                <div className="flex justify-between items-center mb-6">
                    <h3 className="text-xl font-semibold text-on-surface dark:text-dark-on-surface">热门话题</h3>
                    <button className="bg-primary text-primary-content font-semibold py-2 px-4 rounded-lg hover:bg-primary-hover transition-colors dark:bg-dark-primary-DEFAULT dark:text-dark-primary-content dark:hover:bg-dark-primary-hover">
                        发布新话题
                    </button>
                </div>

                <div className="bg-surface rounded-xl border border-border dark:bg-dark-surface dark:border-dark-border">
                    <ul className="divide-y divide-border dark:divide-dark-border">
                        {mockTopics.map(topic => (
                            <li key={topic.id} className="p-4 flex items-start space-x-4 transition-colors hover:bg-black/5 dark:hover:bg-white/5">
                                <img src={topic.avatar} alt={topic.author} className="w-10 h-10 rounded-full" />
                                <div className="flex-1">
                                    <a href="#" className="font-semibold text-on-surface hover:text-primary dark:text-dark-on-surface dark:hover:text-dark-primary-DEFAULT">{topic.title}</a>
                                    <div className="text-xs text-on-surface-variant dark:text-dark-on-surface-variant mt-1 flex items-center space-x-3">
                                        <span>{topic.author}</span>
                                        <span>·</span>
                                        <span>{topic.time}</span>
                                    </div>
                                </div>
                                <div className="text-center flex items-center space-x-2 text-sm text-on-surface-variant dark:text-dark-on-surface-variant">
                                    <svg className="w-4 h-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
                                      <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 12.76c0 1.6 1.123 2.994 2.707 3.227 1.068.157 2.148.279 3.238.364.49.03.984.067 1.483.1a4.06 4.06 0 001.483-.1c1.09-.086 2.17-.208 3.238-.365 1.584-.233 2.707-1.626 2.707-3.228V6.741c0-1.602-1.123-2.995-2.707-3.228A48.344 48.344 0 0012 3c-2.392 0-4.744.175-7.043.513C3.373 3.746 2.25 5.14 2.25 6.741v6.018z" />
                                    </svg>
                                    <span className="font-medium">{topic.replies}</span>
                                </div>
                            </li>
                        ))}
                    </ul>
                </div>
            </div>
        </div>
    );
};