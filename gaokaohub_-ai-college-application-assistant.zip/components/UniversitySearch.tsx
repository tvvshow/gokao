import React, { useState } from 'react';
import { PROVINCES } from '../constants';
import type { University } from '../types';

const mockUniversities: University[] = [
    { name: '北京大学', province: '北京', city: '北京', type: '985, 211', tags: ['综合', '顶尖', '文理强校'] },
    { name: '清华大学', province: '北京', city: '北京', type: '985, 211', tags: ['理工', '顶尖', '工科第一'] },
    { name: '复旦大学', province: '上海', city: '上海', type: '985, 211', tags: ['综合', '江南第一', '名校'] },
    { name: '浙江大学', province: '浙江', city: '杭州', type: '985, 211', tags: ['综合', '巨无霸', '学科齐全'] },
    { name: '南京大学', province: '江苏', city: '南京', type: '985, 211', tags: ['综合', '诚朴雄伟', '历史悠久'] },
    { name: '上海交通大学', province: '上海', city: '上海', type: '985, 211', tags: ['综合', '理工', '实力强劲'] },
    { name: '中国科学技术大学', province: '安徽', city: '合肥', type: '985, 211', tags: ['理工', '精英教育', '学风好'] },
    { name: '武汉大学', province: '湖北', city: '武汉', type: '985, 211', tags: ['综合', '最美校园', '樱花'] },
];

const UniversityCard: React.FC<{ university: University }> = ({ university }) => (
    <div className="bg-surface p-5 rounded-lg border border-border hover:shadow-soft transition-shadow dark:bg-dark-surface dark:border-dark-border dark:hover:border-dark-border-hover">
        <div className="flex justify-between items-start">
            <h3 className="font-bold text-lg text-on-surface dark:text-dark-on-surface">{university.name}</h3>
            <span className="text-sm text-on-surface-variant dark:text-dark-on-surface-variant">{university.province} - {university.city}</span>
        </div>
        <p className="text-sm text-primary font-semibold mt-1 dark:text-dark-primary-DEFAULT">{university.type}</p>
        <div className="mt-3 flex flex-wrap gap-2">
            {university.tags.map(tag => (
                <span key={tag} className="text-xs bg-black/5 text-on-surface-variant px-2 py-1 rounded-full dark:bg-white/5 dark:text-dark-on-surface-variant">{tag}</span>
            ))}
        </div>
        <button className="w-full mt-4 text-sm bg-primary/10 text-primary font-semibold py-2 rounded-lg hover:bg-primary/20 dark:bg-dark-primary-DEFAULT/15 dark:text-dark-primary-DEFAULT dark:hover:bg-dark-primary-DEFAULT/25">
            查看详情
        </button>
    </div>
);


export const UniversitySearch: React.FC = () => {
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedProvince, setSelectedProvince] = useState('all');
    const [universityType, setUniversityType] = useState('all');

    const filteredUniversities = mockUniversities.filter(uni => {
        return (
            uni.name.toLowerCase().includes(searchTerm.toLowerCase()) &&
            (selectedProvince === 'all' || uni.province === selectedProvince) &&
            (universityType === 'all' || uni.type.includes(universityType))
        );
    });

    return (
        <div>
            <div className="text-center mb-8">
                <h2 className="text-3xl font-bold text-on-surface dark:text-dark-on-surface">院校专业检索</h2>
                <p className="text-on-surface-variant mt-2 dark:text-dark-on-surface-variant">精准查询，发现最适合您的院校与专业。</p>
            </div>

            <div className="bg-surface p-6 rounded-xl border border-border shadow-soft mb-8 dark:bg-dark-surface dark:border-dark-border">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <input
                        type="text"
                        placeholder="输入大学名称..."
                        value={searchTerm}
                        onChange={e => setSearchTerm(e.target.value)}
                        className="w-full px-4 py-2 bg-transparent border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-primary dark:border-dark-border dark:focus:ring-dark-primary-DEFAULT dark:focus:border-dark-primary-DEFAULT"
                    />
                    <select
                        value={selectedProvince}
                        onChange={e => setSelectedProvince(e.target.value)}
                        className="w-full px-4 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-primary bg-surface dark:bg-dark-surface dark:border-dark-border dark:focus:ring-dark-primary-DEFAULT dark:focus:border-dark-primary-DEFAULT"
                    >
                        <option value="all">所有省份</option>
                        {PROVINCES.map(p => <option key={p} value={p}>{p}</option>)}
                    </select>
                    <select
                        value={universityType}
                        onChange={e => setUniversityType(e.target.value)}
                        className="w-full px-4 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-primary bg-surface dark:bg-dark-surface dark:border-dark-border dark:focus:ring-dark-primary-DEFAULT dark:focus:border-dark-primary-DEFAULT"
                    >
                        <option value="all">所有类型</option>
                        <option value="985">985院校</option>
                        <option value="211">211院校</option>
                    </select>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredUniversities.length > 0 ? (
                    filteredUniversities.map(uni => (
                        <UniversityCard key={uni.name} university={uni} />
                    ))
                ) : (
                    <p className="col-span-full text-center text-on-surface-variant dark:text-dark-on-surface-variant">未找到符合条件的院校。</p>
                )}
            </div>
        </div>
    );
};