import React, { useState } from 'react';
import { GoogleGenAI, Type } from "@google/genai";
import { PROVINCES, GAOKAO_SUBJECTS } from '../constants';
import type { AISuggestionTier } from '../types';

const Spinner: React.FC = () => (
    <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
    </svg>
);

const TierCard: React.FC<{ tierData: AISuggestionTier }> = ({ tierData }) => {
    const tierStyles = {
        '冲刺': {
            border: 'border-amber-500/50 dark:border-amber-500/40',
            bg: 'bg-amber-500/5 dark:bg-amber-500/10',
            headerBg: 'bg-amber-500/10 text-amber-700 dark:bg-amber-500/15 dark:text-amber-400',
        },
        '稳妥': {
            border: 'border-emerald-500/50 dark:border-emerald-500/40',
            bg: 'bg-emerald-500/5 dark:bg-emerald-500/10',
            headerBg: 'bg-emerald-500/10 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-400',
        },
        '保底': {
            border: 'border-indigo-500/50 dark:border-indigo-500/40',
            bg: 'bg-indigo-500/5 dark:bg-indigo-500/10',
            headerBg: 'bg-indigo-500/10 text-indigo-700 dark:bg-indigo-500/15 dark:text-indigo-400',
        }
    };
    const currentStyle = tierStyles[tierData.tier];

    return (
        <div className={`rounded-xl border ${currentStyle.border} ${currentStyle.bg} overflow-hidden`}>
            <h3 className={`text-xl font-bold p-4 ${currentStyle.headerBg}`}>
                {tierData.tier}院校
            </h3>
            <div className="p-4 space-y-3">
                {tierData.colleges.map((college, index) => (
                    <div key={index} className="bg-surface p-4 rounded-lg shadow-sm border border-border dark:bg-dark-surface dark:border-dark-border">
                        <div className="flex justify-between items-start">
                            <div>
                                <p className="font-bold text-lg text-on-surface dark:text-dark-on-surface">{college.collegeName}</p>
                                <p className="text-primary font-medium dark:text-dark-primary-DEFAULT">{college.major}</p>
                            </div>
                            <div className="text-right flex-shrink-0 ml-4">
                                <p className="text-sm text-on-surface-variant dark:text-dark-on-surface-variant">2023分数</p>
                                <p className="font-semibold text-on-surface dark:text-dark-on-surface">{college.admissionScore2023}</p>
                            </div>
                        </div>
                        <p className="text-sm text-on-surface-variant mt-3 bg-background p-3 rounded-md dark:bg-dark-background dark:text-dark-on-surface-variant">
                            <span className="font-semibold text-on-surface dark:text-dark-on-surface">推荐理由:</span> {college.reason}
                        </p>
                    </div>
                ))}
            </div>
        </div>
    );
};


export const AISuggestion: React.FC = () => {
    const [score, setScore] = useState('');
    const [province, setProvince] = useState(PROVINCES[0]);
    const [subjects, setSubjects] = useState<string[]>([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');
    const [results, setResults] = useState<AISuggestionTier[]>([]);

    const handleSubjectChange = (subject: string) => {
        setSubjects(prev =>
            prev.includes(subject) ? prev.filter(s => s !== subject) : [...prev, subject]
        );
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!score || !province || subjects.length === 0) {
            setError('请填写所有必填项。');
            return;
        }
        setError('');
        setLoading(true);
        setResults([]);

        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
            const prompt = `
              我是一名来自【${province}】的高考生，我的高考分数为【${score}】，选考科目为【${subjects.join(', ')}】。
              请根据我的情况，为我推荐“冲刺”、“稳妥”、“保底”三个梯度的大学和专业志愿。
              每个梯度请推荐2-3个“院校-专业”组合。
              对于每个组合，请提供2023年的参考录取分数、院校排名（综合或专业排名），并给出一句简短的推荐理由。
            `;
            
            const responseSchema = {
                type: Type.ARRAY,
                items: {
                    type: Type.OBJECT,
                    properties: {
                        tier: { type: Type.STRING, description: '梯度，例如：冲刺, 稳妥, 保底' },
                        colleges: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.OBJECT,
                                properties: {
                                    collegeName: { type: Type.STRING },
                                    major: { type: Type.STRING },
                                    admissionScore2023: { type: Type.STRING },
                                    ranking: { type: Type.STRING },
                                    reason: { type: Type.STRING },
                                },
                            },
                        },
                    },
                },
            };

            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: prompt,
                config: {
                    responseMimeType: "application/json",
                    responseSchema: responseSchema,
                },
            });

            const jsonString = response.text.trim();
            const parsedResults = JSON.parse(jsonString) as AISuggestionTier[];
            setResults(parsedResults);

        } catch (err) {
            console.error(err);
            setError('生成建议时出错，请稍后重试。');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="max-w-4xl mx-auto">
            <div className="text-center mb-8">
                <h2 className="text-3xl font-bold text-on-surface dark:text-dark-on-surface">AI 智能志愿填报</h2>
                <p className="text-on-surface-variant mt-2 dark:text-dark-on-surface-variant">输入您的信息，让AI为您量身打造专属志愿方案。</p>
            </div>

            <div className="bg-surface p-8 rounded-xl border border-border shadow-soft dark:bg-dark-surface dark:border-dark-border">
                <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                         <div>
                            <label htmlFor="score" className="block text-sm font-medium text-on-surface-variant mb-1 dark:text-dark-on-surface-variant">高考分数</label>
                            <input
                                type="number"
                                id="score"
                                value={score}
                                onChange={e => setScore(e.target.value)}
                                className="w-full px-4 py-2 bg-transparent border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-primary dark:border-dark-border dark:focus:ring-dark-primary-DEFAULT dark:focus:border-dark-primary-DEFAULT"
                                placeholder="请输入您的预估或实际分数"
                            />
                        </div>
                        <div>
                            <label htmlFor="province" className="block text-sm font-medium text-on-surface-variant mb-1 dark:text-dark-on-surface-variant">所在省份</label>
                            <select
                                id="province"
                                value={province}
                                onChange={e => setProvince(e.target.value)}
                                className="w-full px-4 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-primary bg-surface dark:bg-dark-surface dark:border-dark-border dark:focus:ring-dark-primary-DEFAULT dark:focus:border-dark-primary-DEFAULT"
                            >
                                {PROVINCES.map(p => <option key={p} value={p}>{p}</option>)}
                            </select>
                        </div>
                    </div>
                   
                    <div>
                        <label className="block text-sm font-medium text-on-surface-variant mb-2 dark:text-dark-on-surface-variant">选考科目 (新高考)</label>
                        <div className="flex flex-wrap gap-3">
                            {GAOKAO_SUBJECTS.map(subject => (
                                <button
                                    type="button"
                                    key={subject}
                                    onClick={() => handleSubjectChange(subject)}
                                    className={`px-4 py-2 rounded-full text-sm font-medium border transition-colors ${
                                        subjects.includes(subject)
                                            ? 'bg-primary text-primary-content border-primary dark:bg-dark-primary-DEFAULT dark:text-dark-primary-content dark:border-dark-primary-DEFAULT'
                                            : 'bg-transparent text-on-surface-variant border-border hover:bg-black/5 dark:text-dark-on-surface-variant dark:border-dark-border dark:hover:bg-white/5'
                                    }`}
                                >
                                    {subject}
                                </button>
                            ))}
                        </div>
                    </div>

                    {error && <p className="text-red-500 text-sm">{error}</p>}
                    
                    <button
                        type="submit"
                        disabled={loading}
                        className="w-full flex justify-center items-center bg-primary text-primary-content font-semibold py-3 px-4 rounded-lg hover:bg-primary-hover transition-colors disabled:bg-primary/50 dark:bg-dark-primary-DEFAULT dark:text-dark-primary-content dark:hover:bg-dark-primary-hover dark:disabled:bg-dark-primary-DEFAULT/50"
                    >
                        {loading ? <Spinner /> : '生成我的专属志愿单'}
                    </button>
                </form>
            </div>
            
            {results.length > 0 && (
                <div className="mt-10 space-y-8">
                    {results.map(tier => <TierCard key={tier.tier} tierData={tier} />)}
                </div>
            )}
        </div>
    );
};