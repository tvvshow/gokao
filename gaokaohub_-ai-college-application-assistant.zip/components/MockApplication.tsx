import React, { useState } from 'react';
import type { MockApplicationItem } from '../types';

const PinIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
      <path fillRule="evenodd" d="M10 1a.75.75 0 01.75.75v1.5a.75.75 0 01-1.5 0v-1.5A.75.75 0 0110 1zM5.05 3.55a.75.75 0 011.06 0l1.062 1.06a.75.75 0 01-1.06 1.062L5.05 4.61a.75.75 0 010-1.06zM3 10a.75.75 0 01.75-.75h1.5a.75.75 0 010 1.5h-1.5A.75.75 0 013 10zm2.05 5.512a.75.75 0 010-1.06l1.06-1.062a.75.75 0 011.062 1.06l-1.06 1.06a.75.75 0 01-1.062 0zM10 17a.75.75 0 01-.75.75v1.5a.75.75 0 011.5 0v-1.5A.75.75 0 0110 17zm4.95-2.05a.75.75 0 01-1.06 0l-1.062-1.06a.75.75 0 111.06-1.062l1.06 1.06a.75.75 0 010 1.06zM17 10a.75.75 0 01-.75.75h-1.5a.75.75 0 010-1.5h1.5A.75.75 0 0117 10zm-2.05-5.512a.75.75 0 010 1.06l-1.06 1.062a.75.75 0 11-1.062-1.06l1.06-1.06a.75.75 0 011.062 0z" clipRule="evenodd" />
    </svg>
);


const TrashIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 013.478-.397m7.5 0v-.916c0-1.18-.91-2.134-2.09-2.201a51.964 51.964 0 00-3.32 0c-1.18.067-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 00-7.5 0" />
    </svg>
);


const PlusIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
  </svg>
);

const initialItems: MockApplicationItem[] = [
    { id: 1, university: '北京大学', major: '计算机科学与技术', isPinned: false },
    { id: 2, university: '清华大学', major: '人工智能', isPinned: true },
    { id: 3, university: '复旦大学', major: '临床医学', isPinned: false },
];

export const MockApplication: React.FC = () => {
    const [items, setItems] = useState<MockApplicationItem[]>(initialItems);
    const [newUniversity, setNewUniversity] = useState('');
    const [newMajor, setNewMajor] = useState('');

    const handleAddItem = () => {
        if (newUniversity && newMajor) {
            const newItem: MockApplicationItem = {
                id: Date.now(),
                university: newUniversity,
                major: newMajor,
                isPinned: false,
            };
            setItems([newItem, ...items]);
            setNewUniversity('');
            setNewMajor('');
        }
    };

    const handleRemoveItem = (id: number) => {
        setItems(items.filter(item => item.id !== id));
    };
    
    const handleTogglePin = (id: number) => {
        setItems(items.map(item => item.id === id ? { ...item, isPinned: !item.isPinned } : item));
    }
    
    const pinnedItems = items.filter(i => i.isPinned);
    const unpinnedItems = items.filter(i => !i.isPinned);

    return (
        <div>
            <div className="text-center mb-8">
                <h2 className="text-3xl font-bold text-on-surface dark:text-dark-on-surface">模拟志愿表</h2>
                <p className="text-on-surface-variant mt-2 dark:text-dark-on-surface-variant">在这里管理和调整您的志愿，直到完美。</p>
            </div>
            
            <div className="max-w-3xl mx-auto">
                <div className="bg-surface p-6 rounded-xl border border-border dark:bg-dark-surface dark:border-dark-border mb-6">
                    <h3 className="font-semibold mb-3 text-on-surface dark:text-dark-on-surface">添加新志愿</h3>
                    <div className="flex items-center gap-4">
                        <input
                            type="text"
                            placeholder="大学名称"
                            value={newUniversity}
                            onChange={(e) => setNewUniversity(e.target.value)}
                            className="flex-1 px-4 py-2 bg-transparent border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-primary dark:border-dark-border dark:focus:ring-dark-primary-DEFAULT dark:focus:border-dark-primary-DEFAULT"
                        />
                        <input
                            type="text"
                            placeholder="专业名称"
                            value={newMajor}
                            onChange={(e) => setNewMajor(e.target.value)}
                            className="flex-1 px-4 py-2 bg-transparent border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-primary dark:border-dark-border dark:focus:ring-dark-primary-DEFAULT dark:focus:border-dark-primary-DEFAULT"
                        />
                        <button onClick={handleAddItem} className="bg-primary text-primary-content p-2 rounded-lg hover:bg-primary-hover dark:bg-dark-primary-DEFAULT dark:text-dark-primary-content dark:hover:bg-dark-primary-hover">
                          <PlusIcon className="w-6 h-6"/>
                        </button>
                    </div>
                </div>

                <div className="space-y-3">
                    {[...pinnedItems, ...unpinnedItems].map((item, index) => (
                        <div key={item.id} className={`bg-surface p-4 rounded-lg border flex items-center justify-between transition-shadow hover:shadow-soft dark:bg-dark-surface dark:border-dark-border ${item.isPinned ? 'border-primary/50 dark:border-dark-primary-DEFAULT/50' : 'border-border dark:border-dark-border'}`}>
                            <div className="flex items-center">
                                <span className="text-lg font-bold text-on-surface-variant w-8 dark:text-dark-on-surface-variant">{index + 1}</span>
                                <div className="ml-2">
                                    <p className="font-bold text-on-surface dark:text-dark-on-surface">{item.university}</p>
                                    <p className="text-sm text-on-surface-variant dark:text-dark-on-surface-variant">{item.major}</p>
                                </div>
                            </div>
                            <div className="flex items-center gap-1">
                                <button onClick={() => handleTogglePin(item.id)} className={`p-2 rounded-full hover:bg-black/5 dark:hover:bg-white/5 ${item.isPinned ? 'text-primary dark:text-dark-primary-DEFAULT' : 'text-on-surface-variant/50 dark:text-dark-on-surface-variant/50'}`}>
                                    <PinIcon className="w-5 h-5"/>
                                </button>
                                <button onClick={() => handleRemoveItem(item.id)} className="p-2 rounded-full text-on-surface-variant/50 hover:bg-red-500/10 hover:text-red-500 dark:text-dark-on-surface-variant/50 dark:hover:bg-red-500/15 dark:hover:text-red-400">
                                    <TrashIcon className="w-5 h-5"/>
                                </button>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};